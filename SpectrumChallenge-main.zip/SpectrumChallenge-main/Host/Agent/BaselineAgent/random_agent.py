from utility.environment_interface import EnvironmentInterface


env = EnvironmentInterface()
env.connect()
env.start_simulation(time_us=10000)
env.random_action_step(num_step=10000)

