import socket
import logging
from utility.messenger import Messenger
from typing import TYPE_CHECKING, Optional, List, Dict
from arena_server.controller import RemoteController
from arena_server.simulator import Simulator
if TYPE_CHECKING:
    from arena_server.network_operator import NetworkOperator

logger = logging.getLogger(__name__)


class RemotePlayer:
    def __init__(self, player_id: str, network_operator_name: str):
        self._player_id: str = player_id
        self._network_operator_name: str = network_operator_name
        self._messenger: Optional['Messenger'] = None
        self._remote_controller = RemoteController()
        self._network_operator: Optional['NetworkOperator'] = None

    @property
    def player_id(self):
        return self._player_id

    @property
    def network_operator_name(self):
        return self._network_operator_name

    @property
    def network_operator(self):
        return self._network_operator

    @property
    def messenger(self):
        return self._messenger

    def set_remote_connection(self, messenger: Messenger):
        self._messenger = messenger
        self._remote_controller.set_messenger(self._messenger)

    def is_connected(self):
        return self._messenger is not None

    def attach_network_operator(self, network_operator: 'NetworkOperator'):
        self._network_operator = network_operator
        self._network_operator.set_controller(self._remote_controller)

    def detach_network_operator(self):
        self._network_operator.detach_controller()
        self._network_operator = None

    def send_network_operator_info_to_player(self):
        operator_info = self._network_operator.get_information()
        self._messenger.send('operator_info', operator_info)


class RemotePlayerManager:
    def __init__(self):
        self._server_address: str = ''
        self._server_port: int = 0
        self._server_socket = None
        self._remote_player_dict: Dict[str, RemotePlayer] = {}

    @property
    def remote_player_dict(self):
        return self._remote_player_dict

    def is_remote_player_exist(self):
        return len(self._remote_player_dict) > 0

    def register_remote_player(self, player_id: str, network_operator_name: str):
        self._remote_player_dict[player_id] = RemotePlayer(player_id, network_operator_name)

    def set_server_socket(self, server_address: str, server_port: int):
        self._server_address = server_address
        self._server_port = server_port
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.bind((self._server_address, self._server_port))
        self._server_socket.listen()

    def connect_to_players(self):
        player_id_list = list(self._remote_player_dict.keys())
        while player_id_list:
            client_socket, client_address = self._server_socket.accept()
            messenger = Messenger(client_socket)
            msg_type, player_id = messenger.recv()
            if msg_type == 'player_id' and (player_id in player_id_list):
                remote_player = self._remote_player_dict[player_id]
                remote_player.set_remote_connection(messenger)
                remote_player.messenger.send('connection_successful')
                player_id_list.remove(player_id)
                logger.info(f"Player {player_id} connected")
            else:
                client_socket.close()

    def attach_simulator(self, simulator: 'Simulator'):
        for remote_player in self._remote_player_dict.values():
            network_operator_name = remote_player.network_operator_name
            network_operator = simulator.get_network_operator_by_name(network_operator_name)
            remote_player.attach_network_operator(network_operator)

    def detach_simulator(self):
        for remote_player in self._remote_player_dict.values():
            remote_player.detach_network_operator()

    def send_network_operator_info_to_players(self):
        for remote_player in self._remote_player_dict.values():
            remote_player.send_network_operator_info_to_player()

    def send_simulation_finished_msg_to_players(self):
        for remote_player in self._remote_player_dict.values():
            remote_player.messenger.send('simulation_finished')

    def send_msg_to_player(self, player_id, msg_type, msg=''):
        remote_player = self._remote_player_dict[player_id]
        remote_player.messenger.send(msg_type, msg)

    def recv_msg_from_player(self, player_id):
        remote_player = self._remote_player_dict[player_id]
        msg_type, msg = remote_player.messenger.recv()
        return msg_type, msg
