from typing import TYPE_CHECKING, Dict, Optional
if TYPE_CHECKING:
    from arena_server.network_operator import NetworkOperator
    from arena_server.simulator import Simulator
    from utility.messenger import Messenger


class Controller:
    def __init__(self):
        self._network_operator: Optional['NetworkOperator'] = None
        self._simulator: Optional['Simulator'] = None

    @property
    def network_operator(self):
        return self._network_operator

    @property
    def simulator(self):
        return self._simulator

    def set_network_operator(self, network_operator: 'NetworkOperator'):
        self._network_operator = network_operator

    def set_simulator(self, simulator):
        self._simulator = simulator

    def detach_network_operator(self):
        self._network_operator = None
        self._simulator = None

    def request_decision(self, observation: Dict) -> Dict:
        raise NotImplementedError


class RemoteController(Controller):
    def __init__(self):
        super(Controller, self).__init__()
        self._messenger: Optional['Messenger'] = None

    def set_messenger(self, messenger: 'Messenger'):
        self._messenger = messenger

    def request_decision(self, observation: Dict) -> Optional[Dict]:
        score = self.network_operator.get_score()
        self._messenger.send('observation', {'observation': observation, 'score': score})
        msg_type, msg = self._messenger.recv()
        if msg_type == 'action':
            return msg
        else:
            return None
