import logging
from arena_server.simulator import Simulator
from arena_server.simulation_logger import SimulationLogger
from arena_server.remote_player_manager import RemotePlayerManager
from typing import TYPE_CHECKING, Optional, List
if TYPE_CHECKING:
    from arena_server.network_operator import NetworkOperator
    from arena_server.node import Node

logger = logging.getLogger(__name__)


class Environment:
    def __init__(self):
        self._status = 'uninitialized'
        self._simulation_logger = SimulationLogger()
        self._video_logging_enabled = False
        self._text_logging_enabled = False
        self._remote_player_manager: RemotePlayerManager = RemotePlayerManager()
        self._center_freq_list: Optional[List] = None
        self._network_operator_config: List = []

    def set_center_freq_list(self, center_freq_list):
        self._center_freq_list = center_freq_list

    def register_remote_player(self, remote_player_id: str, network_operator_name: str):
        self._remote_player_manager.register_remote_player(remote_player_id, network_operator_name)

    def add_network_operator_config(self, network_class, network_args, mobility_class, mobility_args,
                                    controller_type, controller_class=None, controller_args=None):
        net_op_conf = {'network_class': network_class, 'network_args': network_args,
                       'mobility_class': mobility_class, 'mobility_args': mobility_args,
                       'controller_type': controller_type, 'controller_class': controller_class,
                       'controller_args': controller_args}
        self._network_operator_config.append(net_op_conf)

    def configure_video_logging(self, video_file_name: str = 'result_movie', clock_interval: int = 10,
                                show_live_video=False, plane_size=(40, 40), resolution=(1440, 720), frame_rate=30):
        self._simulation_logger.configure_video_logging(video_file_name, clock_interval, show_live_video,
                                                        plane_size, resolution, frame_rate)

    def enable_video_logging(self):
        self._video_logging_enabled = True

    def disable_video_logging(self):
        self._video_logging_enabled = False

    def configure_text_logging(self, text_file_name):
        self._simulation_logger.configure_text_logging(text_file_name)

    def enable_text_logging(self):
        self._text_logging_enabled = True

    def disable_text_logging(self):
        self._text_logging_enabled = False

    def get_simulator(self):
        simulator = Simulator(self._center_freq_list)
        return simulator

    def send_msg_to_player(self, player_id, msg_type, msg=''):
        self._remote_player_manager.send_msg_to_player(player_id, msg_type, msg)

    def recv_msg_from_player(self, player_id):
        msg_type, msg = self._remote_player_manager.recv_msg_from_player(player_id)
        return msg_type, msg

    def set_up_network_operators_to_simulator(self, sim):
        for net_op_conf in self._network_operator_config:
            sim.add_network_operator_from_config(net_op_conf)

    def initialize(self):
        if self._remote_player_manager.is_remote_player_exist():
            self._remote_player_manager.set_server_socket('127.0.0.1', 8888)
            logger.info(f"Wait for player(s) to connect")
            self._remote_player_manager.connect_to_players()
        self._status = 'idle'

    def exec_simulator(self, until: float):
        sim = self.get_simulator()
        self._simulation_logger.attach_simulator(sim)
        if self._text_logging_enabled:
            self._simulation_logger.start_text_logging()
        if self._video_logging_enabled:
            self._simulation_logger.start_video_logging()
        self.set_up_network_operators_to_simulator(sim)
        self._remote_player_manager.attach_simulator(sim)
        self._remote_player_manager.send_network_operator_info_to_players()
        sim.set_time_logging(100000)
        self._status = 'running'
        score = sim.run(until)
        self._status = 'idle'
        self._simulation_logger.end_text_logging()
        self._simulation_logger.end_video_logging()
        self._remote_player_manager.detach_simulator()
        self._simulation_logger.detach_simulator()
        self._remote_player_manager.send_simulation_finished_msg_to_players()
        return score






