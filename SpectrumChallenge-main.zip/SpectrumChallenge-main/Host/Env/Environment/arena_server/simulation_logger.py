from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional, TextIO, Tuple
from arena_server.visualization import Visualization
if TYPE_CHECKING:
    from arena_server.simulator import Simulator


class SimulationLogger:
    def __init__(self):
        self._clock_interval: int = 0
        self._simulator: Optional['Simulator'] = None
        self._text_file_name: Optional[str] = None
        self._text_file_cnt: int = 0
        self._text_file_descriptor: Optional[TextIO] = None
        self._video_file_name: Optional[str] = None
        self._clock_interval: int = 10
        self._show_live_video: bool = False
        self._plane_size: Tuple[float, float] = (40, 40)
        self._resolution: Tuple[int, int] = (1440, 720)
        self._frame_rate: int = 30
        self._video_file_cnt: int = 0
        self._visualization: Optional[Visualization] = None
        self._print_log: bool = False

    def attach_simulator(self, simulator: 'Simulator'):
        self._simulator = simulator
        self._simulator.set_simulation_logger(self)

    def detach_simulator(self):
        self._simulator.unset_simulation_logger()
        self._simulator = None

    def set_clock(self, clock_interval: float):
        self._clock_interval = clock_interval
        self._simulator.register_process(self._run_clock())

    def _run_clock(self):
        while True:
            self.logging({'type': 'clock'})
            time_out_event = self._simulator.get_timeout_event(self._clock_interval)
            yield time_out_event

    def configure_text_logging(self, text_file_name: str = 'output'):
        self._text_file_name = text_file_name

    def start_text_logging(self):
        if self._text_file_name and (self._text_file_descriptor is None):
            file_dir = Path(__file__).parents[1].resolve() / 'output'
            self._text_file_cnt += 1
            file_name = self._text_file_name + '_' + str(self._text_file_cnt) + '.txt'
            file_path = str(file_dir / file_name)
            self._text_file_descriptor = open(file_path, 'w')

    def end_text_logging(self):
        if self._text_file_descriptor:
            self._text_file_descriptor.close()
            self._text_file_descriptor = None

    def configure_video_logging(self, video_file_name: str = 'result_movie', clock_interval: int = 10,
                                show_live_video=False, plane_size=(40, 40), resolution=(1440, 720), frame_rate=30):
        self._video_file_name = video_file_name
        self._clock_interval = clock_interval
        self._show_live_video = show_live_video
        self._plane_size = plane_size
        self._resolution = resolution
        self._frame_rate = frame_rate

    def start_video_logging(self):
        if self._video_file_name and (self._visualization is None):
            self.set_clock(clock_interval=self._clock_interval)
            file_dir = Path(__file__).parents[1].resolve() / 'output'
            self._video_file_cnt += 1
            file_name = self._video_file_name + '_' + str(self._video_file_cnt) + '.mp4'
            file_path = str(file_dir / file_name)
            self._visualization = Visualization(max_num_line_object=200, plane_size=self._plane_size, node_size=0.4,
                                                video_file_path=file_path, activate_time_domain_view=True,
                                                show_video=self._show_live_video, resolution=self._resolution,
                                                frame_rate=self._frame_rate)

    def end_video_logging(self):
        if self._visualization:
            self._visualization.close()
            self._visualization = None

    def enable_print_logging(self):
        self._print_log = True

    def disable_print_logging(self):
        self._print_log = False

    def logging(self, log: Dict):
        time_log = {'time': self._simulator.now()}
        time_log.update(log)
        if self._text_file_descriptor:
            self._text_file_descriptor.write(f'{time_log}\n')
        if self._visualization:
            self._visualization(time_log)
        if self._print_log:
            print(f'{time_log}')

