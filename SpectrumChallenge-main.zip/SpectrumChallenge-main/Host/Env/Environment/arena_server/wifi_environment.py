import os
from pathlib import Path
import yaml
import logging
import json
import argparse
from arena_server.wifi_network_operator import WiFiNetworkOperator
from arena_server.mobility import WiFiRandomWaypointMobility
from arena_server.wifi_bot_controller import WiFiCSMAController, WiFiPeriodicController, WiFiRandomPeriodicController
from arena_server.wifi_parameter import WiFiParam
from arena_server.environment import Environment
from arena_server.API_utils import API_Interface
from typing import TYPE_CHECKING, Any, Optional, Generator, List, Dict
if TYPE_CHECKING:
    from arena_server.network_operator import NetworkOperator
    from arena_server.node import Node

logging.basicConfig(level=logging.INFO, format='%(message)s')


class WiFiEnvironment(Environment):
    def __init__(self, config_file: str, evaluation_mode: bool, evaluation_time: int, send_to_api: bool):
        super().__init__()
        self._remote_player_id = 'p1'
        self._remote_player_dict: Dict = {}
        self._evaluation_mode = evaluation_mode
        self._evaluation_time = evaluation_time
        self._send_to_api = send_to_api
        self.configure_from_yaml(config_file)

    def configure_from_yaml(self, config_file: str):
        file_dir = Path(__file__).parents[1].resolve() / 'simulation_config'
        yaml_file = file_dir / config_file
        with open(yaml_file) as f:
            config = yaml.safe_load(f)
        eval_conf = config['evaluation']
        scoring_param = {'packet_overhead': eval_conf['packet_overhead'],
                         'collision_penalty_weight': eval_conf['collision_penalty_weight']}
        num_frequency_channel = config['num_frequency_channel']
        freq_channel_list = list(range(num_frequency_channel))
        max_num_unit_packet = config['max_num_unit_packet']
        num_unit_packet_list = list(range(1, max_num_unit_packet+1))
        self.set_center_freq_list(WiFiParam.FREQUENCY_LIST_10MHZ[0: num_frequency_channel])
        for conf in config['network_operator']:
            net_class = eval(conf['network']['class'])
            net_args = conf['network']['args']
            net_args['freq_channel_list'] = freq_channel_list
            net_args['num_unit_packet_list'] = num_unit_packet_list
            mob_class = eval(conf['mobility']['class'])
            mob_args = conf['mobility']['args']
            cont_type = conf['controller']['type']
            if cont_type == 'local':
                cont_class = eval(conf['controller']['class'])
                cont_args = conf['controller']['args']
            else:
                if self._remote_player_dict:
                    raise Exception('Only one remote player is allowed.')
                else:
                    self._remote_player_dict[self._remote_player_id] = net_args['name']
                    net_args['scoring_param'] = scoring_param
                cont_class = None
                cont_args = None
            self.add_network_operator_config(net_class, net_args, mob_class, mob_args, cont_type, cont_class, cont_args)
        if self._remote_player_dict:
            self.register_remote_player(self._remote_player_id, self._remote_player_dict[self._remote_player_id])
        text_conf = config['logging']['text_logging']
        self.configure_text_logging(text_conf['text_file_name'])
        if text_conf['enabled'] and not self._evaluation_mode:
            self.enable_text_logging()
        vid_conf = config['logging']['video_logging']
        self.configure_video_logging(video_file_name=vid_conf['video_file_name'], clock_interval=vid_conf['clock_interval'],
                                     show_live_video=vid_conf['show_live_video'], plane_size=vid_conf['plane_size'],
                                     resolution=vid_conf['resolution'], frame_rate=vid_conf['frame_rate'])
        if vid_conf['enabled'] and not self._evaluation_mode:
            self.enable_video_logging()
        if config['logging']['print_logging']['enabled'] and not self._evaluation_mode:
            self._simulation_logger.enable_print_logging()

    @staticmethod
    def _send_score(score):
        packet_success = score['packet_success']
        collision = score['collision']
        total_score = score['total_score']
        api = API_Interface(AUTH_TOKEN=os.environ.get("AUTH_TOKEN", "x"),
                            EVALAI_API_SERVER=os.environ.get("EVALAI_API_SERVER", "http://localhost:8000"))
        BODY = os.environ.get("BODY")
        BODY = BODY.replace("'", '"')
        BODY = json.loads(BODY)
        challenge_pk = BODY["challenge_pk"]
        phase_pk = BODY["phase_pk"]
        submission_pk = BODY["submission_pk"]
        submission_data = {
            "challenge_phase": phase_pk,
            "submission": submission_pk,
            "stdout": "standard_output",
            "stderr": "standard_error",
            "submission_status": "FINISHED",
            "result": json.dumps(
                [
                    {
                        "split": "train_split",
                        "show_to_participant": True,
                        "accuracies": {"Packet Success": packet_success, "Collision": collision,
                                       "Total Score": total_score}
                    }
                ]
            )
        }
        api.update_submission_data(submission_data, challenge_pk)

    def run(self, time_us=1000):
        self.initialize()
        if self._evaluation_mode:
            while True:
                msg_type, msg = self.recv_msg_from_player(self._remote_player_id)
                if msg_type == 'start_simulation':
                    break
                elif msg_type == 'configure_logging':
                    self.send_msg_to_player(self._remote_player_id, msg_type='logging_configured')
            logging.info("Simulation started.")
            score = env.exec_simulator(self._evaluation_time)
            score = score[self._remote_player_dict[self._remote_player_id]]
            logging.info("Simulation has ended.")
            logging.info(f"Final score is {score}.")
            if self._send_to_api:
                logging.info("Submitting score to server.")
                self._send_score(score)
                logging.info("Score submitted to server.")
        elif self._remote_player_dict:
            while True:
                msg_type, msg = self.recv_msg_from_player(self._remote_player_id)
                if msg_type == 'start_simulation':
                    time_us = msg
                    logging.info("Simulation started.")
                    env.exec_simulator(time_us)
                    logging.info("Simulation has ended.")
                if msg_type == 'configure_logging':
                    log_type = msg['log_type']
                    enable = msg['enable']
                    if log_type == 'video':
                        if enable:
                            self.enable_video_logging()
                        else:
                            self.disable_video_logging()
                    elif log_type == 'text':
                        if enable:
                            self.enable_text_logging()
                        else:
                            self.disable_text_logging()
                    self.send_msg_to_player(self._remote_player_id, msg_type='logging_configured')
        else:
            logging.info("Simulation started.")
            env.exec_simulator(time_us)
            logging.info("Simulation has ended.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    def str2bool(v):
        if isinstance(v, bool):
            return v
        if v.lower() in ('T', 'True', 't', 'true'):
            return True
        elif v.lower() in ('F', 'False', 'f', 'false'):
            return False
        else:
            raise argparse.ArgumentTypeError('Boolean value expected.')

    parser.add_argument('--config_file', '-c', type=str, default='wifi_remote.yaml')
    parser.add_argument('--evaluation_mode', '-m', type=str2bool, default=False)
    parser.add_argument('--evaluation_time', '-t', type=int, default=10000000)
    parser.add_argument('--send_to_api', '-s',type=str2bool, default=False)
    args = parser.parse_args()
    print(args.config_file, args.evaluation_mode, args.evaluation_time, args.send_to_api)
    env = WiFiEnvironment(args.config_file, args.evaluation_mode, args.evaluation_time, args.send_to_api)
    env.run()




