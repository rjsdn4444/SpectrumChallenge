import simpy
import logging
from arena_server.channel_model import ChannelNetworkModel
from arena_server.radio import RadioEnvironment
from arena_server.simulation_logger import SimulationLogger
from typing import TYPE_CHECKING, Any, Optional, Generator, List, Dict
if TYPE_CHECKING:
    from arena_server.network_operator import NetworkOperator
    from arena_server.node import Node
    from arena_server.simulation_logger import SimulationLogger

logging.basicConfig(level=logging.INFO, format='%(message)s')


class Simulator:
    def __init__(self, center_freq_list):
        self._center_freq = center_freq_list
        self._freq_channel_list = list(range(len(self._center_freq)))
        self._des_env: simpy.Environment = simpy.Environment()
        self._channel_network_model: ChannelNetworkModel = ChannelNetworkModel('Friis', self._center_freq)
        self._radio_env: 'RadioEnvironment' = RadioEnvironment(self, len(self._center_freq))
        self._node_list: List['Node'] = []
        self._network_operator_dict: Dict[str, 'NetworkOperator'] = {}
        self._simulation_logger: Optional['SimulationLogger'] = None
        self._score: Dict = {}

    @property
    def freq_channel_list(self) -> List:
        return self._freq_channel_list

    @property
    def logger(self) -> 'SimulationLogger':
        return self._simulation_logger

    @property
    def channel_network_model(self) -> 'ChannelNetworkModel':
        return self._channel_network_model

    @property
    def radio_env(self) -> 'RadioEnvironment':
        return self._radio_env

    def set_simulation_logger(self, simulation_logger: 'SimulationLogger'):
        self._simulation_logger = simulation_logger

    def unset_simulation_logger(self):
        self._simulation_logger = None

    def add_node(self, node: 'Node'):
        self._simulation_logger.logging({'type': 'add node', 'name': node.name, 'node type': node.node_type,
                                         'network operator': node.network_operator.name})
        node.set_simulator(self)
        self._node_list.append(node)
        self.channel_network_model.add_node_and_link(node)

    def add_network_operator(self, network_operator: 'NetworkOperator'):
        self._simulation_logger.logging({'type': 'add network operator', 'name': network_operator.name})
        network_operator.set_simulator(self)
        self._network_operator_dict[network_operator.name] = network_operator

    def add_network_operator_from_config(self, conf):
        net_class = conf['network_class']
        net_args = conf['network_args']
        net = net_class(**net_args)
        mob_class = conf['mobility_class']
        mob_args = conf['mobility_args']
        mob = mob_class(**mob_args)
        net.set_mobility(mob)
        cont_type = conf['controller_type']
        if cont_type == 'local':
            cont_class = conf['controller_class']
            cont_args = conf['controller_args']
            cont = cont_class(**cont_args)
            net.set_controller(cont)
        self.add_network_operator(net)

    def get_network_operator_by_name(self, network_operator_name: str):
        return self._network_operator_dict[network_operator_name]

    def register_process(self, generator: Generator[simpy.events.Event, Any, Any]):
        self._des_env.process(generator)

    def get_event(self) -> simpy.Event:
        return self._des_env.event()

    def get_timeout_event(self, delay: float, value: Optional[Any] = None) -> simpy.Timeout:
        return self._des_env.timeout(delay, value)

    def now(self) -> float:
        return self._des_env.now

    def get_score(self, network_operator_name: str) -> Dict:
        if network_operator_name in self._score:
            return self._score[network_operator_name]
        else:
            return {}

    def update_score(self, network_operator_name: str, score: Dict):
        self._score[network_operator_name] = score

    def set_time_logging(self, log_time_period):
        self.register_process(self._time_logging(log_time_period))

    def _time_logging(self, log_time_period):
        while True:
            logging.info(f"Simulation time: {self.now()} us")
            event = self.get_timeout_event(log_time_period)
            yield event

    def run(self, until: float):
        self.logger.logging({'type': 'frequency', 'freq channel list': self._freq_channel_list})
        self.logger.logging({'type': 'start simulation'})
        self._des_env.run(until)
        return self._score





